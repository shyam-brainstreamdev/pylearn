import argparse
from base.ProcessManager import ProcessManager 

parser = argparse.ArgumentParser()
sub = parser.add_subparsers(dest="command")

add = sub.add_parser("add")
add.add_argument("--id", type=int, required=True)
add.add_argument("--name", required=True)
add.add_argument("--city", required=True)
add.add_argument("--org", default='main')

lists = sub.add_parser("list")
lists.add_argument("--org", default='main')

edit = sub.add_parser("edit")
edit.add_argument("--id", type=int, required=True)
edit.add_argument("--name")
edit.add_argument("--city")
edit.add_argument("--org", default='main')

args = parser.parse_args()

processManager = ProcessManager(args.org)
if args.command == 'add':
    processManager.add(name = args.name, city = args.city, id = args.id)

elif args.command == 'list':
    processManager.listing()

elif args.command == 'edit':
    processManager.modify(name = args.name, city = args.city, id = args.id)

processManager.process()