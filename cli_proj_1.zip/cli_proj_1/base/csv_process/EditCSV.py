from base.csv_process.BaseCSV import BaseCSV


class EditCSV(BaseCSV):

    def __init__(self, org, id, name=None, city=None):
        super().__init__(org)
        self.id = id
        self.name = name
        self.city = city

    def processRun(self):

        rows = self.read_rows()

        updated = False

        for row in rows:

            if int(row["id"]) == self.id:

                if self.name:
                    row["name"] = self.name

                if self.city:
                    row["city"] = self.city

                updated = True

        if updated:
            self.write_rows(rows)
            print("Record updated.")
        else:
            print("ID not found.")