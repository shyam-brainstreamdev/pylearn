from base.csv_process.BaseCSV import BaseCSV


class ListCSV(BaseCSV):

    def __init__(self, org):
        super().__init__(org)

    def processRun(self):

        rows = self.read_rows()

        if not rows:
            print("No records.")
            return

        print("-" * 40)

        for row in rows:
            print(
                f'{row["id"]:<5}'
                f'{row["name"]:<20}'
                f'{row["city"]}'
            )

        print("-" * 40)