from pathlib import Path
import csv

class BaseCSV:
    HEADER = ["id", "name", "city"]

    def __init__(self, org):
        self.orgname = org
        self._csvpath = Path(__file__).resolve().parent / "data"
        self._csvpath.mkdir(exist_ok=True)

    @property
    def orgname(self):
        return self._org

    @orgname.setter
    def orgname(self, org):
        self._org = org

    @property
    def csvfile(self):
        return self._csvpath / f"{self.orgname}.csv"
    
    @property
    def csvdir(self):
        return self._csvpath
    
    @property
    def csvname(self):
        return f"{self.orgname}.csv"
    
    def ensure_csv(self):
        try:
            if not self.csvfile.exists():
                with open(self.csvfile, "w", newline="") as file:
                    writer = csv.writer(file)
                    writer.writerow(self.HEADER)

        except PermissionError:
            print("Permission denied while creating CSV.")

        except OSError as e:
            print(f"Unable to create CSV: {e}")

    def read_rows(self):

        try:
            self.ensure_csv()

            with open(self.csvfile, newline="") as file:
                return list(csv.DictReader(file))

        except FileNotFoundError:
            print("CSV file not found.")
            return []

        except csv.Error as e:
            print(f"CSV read error: {e}")
            return []

        except Exception as e:
            print(f"Unexpected error: {e}")
            return []

    def write_rows(self, rows):

        try:
            with open(self.csvfile, "w", newline="") as file:
                writer = csv.DictWriter(file, fieldnames=self.HEADER)
                writer.writeheader()
                writer.writerows(rows)

        except PermissionError:
            print("Permission denied while writing CSV.")

        except Exception as e:
            print(f"Write failed: {e}")

    def processRun(self):
        raise NotImplementedError