from base.csv_process.BaseCSV import BaseCSV
import csv


class AddCSV(BaseCSV):

    def __init__(self, org, id, name, city):
        super().__init__(org)
        self.id = id
        self.name = name
        self.city = city

    def processRun(self):

        rows = self.read_rows()

        for row in rows:
            if int(row["id"]) == self.id:
                print("ID already exists.")
                return

        with open(self.csvfile, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([self.id, self.name, self.city])

        print("Record added.")