from base.csv_process.AddCSV import AddCSV
from base.csv_process.EditCSV import EditCSV
from base.csv_process.ListCSV import ListCSV

class ProcessManager(AddCSV, ListCSV, EditCSV):
    def __init__(self, org):
        self._org = org
        self._process=None

    def add(self, id, name, city):
        self._process = AddCSV(self._org, id, name, city)

    def listing(self):
        self._process = ListCSV(self._org)

    def modify(self, id,name,city):
        self._process = EditCSV(self._org, id, name, city)

    def process(self):
        if(self._process == None):
            print('Error')
        else:
            self._process.processRun()